import 'review.dart';

class Game {
  final String id;
  String name;
  DateTime releaseDate;
  String genre;
  final String creatorId;
  List<Review> reviews;

  Game({
    required this.id,
    required this.name,
    required this.releaseDate,
    required this.genre,
    required this.creatorId,
    List<Review>? reviews,
  }) : reviews = reviews ?? [];
}
