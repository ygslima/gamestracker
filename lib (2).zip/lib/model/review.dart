import 'user.dart';
import 'game.dart';

class Review {
  final User user;
  final Game game;
  double rating;
  String description;
  DateTime timestamp;

  Review({
    required this.user,
    required this.game,
    required this.rating,
    required this.description,
    required this.timestamp,
  });
}
