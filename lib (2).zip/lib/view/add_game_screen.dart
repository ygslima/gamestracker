import 'package:flutter/material.dart';
import '../controller/game_controller.dart';
import '../controller/auth_controller.dart';
import '../model/game.dart';

class AddGameScreen extends StatefulWidget {
  final GameController gameController;
  final AuthController authController;

  AddGameScreen({required this.gameController, required this.authController});

  @override
  _AddGameScreenState createState() => _AddGameScreenState();
}

class _AddGameScreenState extends State<AddGameScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _releaseDateController = TextEditingController();
  final _genreController = TextEditingController();

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final newGame = Game(
        id: DateTime.now().toString(),
        name: _nameController.text,
        releaseDate: DateTime.parse(_releaseDateController.text),
        genre: _genreController.text,
        creatorId: widget.authController.currentUser!.id,
      );

      widget.gameController.addGame(newGame);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar novo jogo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Nome do jogo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o nome do jogo';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _releaseDateController,
                decoration: InputDecoration(labelText: 'Data de lançamento (YYYY-MM-DD)'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a data de lançamento';
                  }
                  if (DateTime.tryParse(value) == null) {
                    return 'Por favor, insira uma data válida';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _genreController,
                decoration: InputDecoration(labelText: 'Gênero'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o gênero';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Adicionar Jogo'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
