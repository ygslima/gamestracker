// game_details_screen.dart

import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';
import '../model/review.dart';
import 'add_review_screen.dart';
import 'edit_game_screen.dart'; // Add this import

class GameDetailsScreen extends StatefulWidget {
  final Game game; // Keep this final
  final GameController gameController;
  final AuthController authController;

  GameDetailsScreen({required this.game, required this.gameController, required this.authController});

  @override
  _GameDetailsScreenState createState() => _GameDetailsScreenState();
}

class _GameDetailsScreenState extends State<GameDetailsScreen> {
  late Game _currentGame;
  double? _averageRating;

  @override
  void initState() {
    super.initState();
    _currentGame = widget.game;
    _calculateAverageRating();
  }

  void _calculateAverageRating() {
    if (_currentGame.reviews.isNotEmpty) {
      final totalRating = _currentGame.reviews.map((review) => review.rating).reduce((a, b) => a + b);
      setState(() {
        _averageRating = totalRating / _currentGame.reviews.length;
      });
    } else {
      setState(() {
        _averageRating = null;
      });
    }
  }

  void _addReview(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddReviewScreen(
          user: widget.authController.currentUser!,
          game: _currentGame,
          gameController: widget.gameController,
          onReviewAdded: _updateReviews,
        ),
      ),
    ).then((_) {
      _calculateAverageRating();
      setState(() {});
    });
  }

  void _editReview(BuildContext context, Review review) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddReviewScreen(
          user: widget.authController.currentUser!,
          game: _currentGame,
          gameController: widget.gameController,
          review: review,
          onReviewAdded: _updateReviews,
        ),
      ),
    ).then((_) {
      _calculateAverageRating();
      setState(() {});
    });
  }

  void _updateReviews() {
    _calculateAverageRating();
    setState(() {
      // Trigger a rebuild to update the UI
    });
  }

  void _deleteGame(BuildContext context) {
    widget.gameController.deleteGame(_currentGame);
    Navigator.of(context).pop(); // Volta para a tela anterior após deletar
  }

  void _editGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => EditGameScreen(
          game: _currentGame,
          gameController: widget.gameController,
          onGameEdited: (updatedGame) {
            setState(() {
              _currentGame = updatedGame;
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text(_currentGame.name),
      actions: [
        IconButton(
          icon: Icon(Icons.edit),
          onPressed: () => _editGame(context),
        ),
      ],
    ),
    body: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Nome: ${_currentGame.name}', style: TextStyle(fontSize: 20)),
          Text('Gênero: ${_currentGame.genre}', style: TextStyle(fontSize: 18)),
          Text('Data de lançamento: ${_currentGame.releaseDate.toLocal().toString().split(' ')[0]}', style: TextStyle(fontSize: 18)),
          SizedBox(height: 20),
          _averageRating != null
              ? Text('Média das notas: ${_averageRating!.toStringAsFixed(1)}', style: TextStyle(fontSize: 18))
              : Text('Média das notas: Sem reviews', style: TextStyle(fontSize: 18)),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: widget.authController.currentUser!.isGuest ? null : () => _addReview(context),
            child: Text('Adicionar Review'),
          ),
          SizedBox(height: 20),
          Text('Reviews:', style: TextStyle(fontSize: 18)),
          Expanded(
            child: ListView.builder(
              itemCount: _currentGame.reviews.length,
              itemBuilder: (context, index) {
                final review = _currentGame.reviews[index];
                return ListTile(
                  title: Text('Nota: ${review.rating}'),
                  subtitle: Text(review.description),
                  trailing: IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () => _editReview(context, review),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}
}