import 'package:flutter/material.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';
import '../model/review.dart';
import '../model/user.dart';

class AddReviewScreen extends StatefulWidget {
  final Game game;
  final GameController gameController;
  final User user;
  final VoidCallback onReviewAdded; // Add this line

  AddReviewScreen({required this.game, required this.gameController, required this.user, required this.onReviewAdded}); // Modify this line

  @override
  _AddReviewScreenState createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  final _formKey = GlobalKey<FormState>();
  final _ratingController = TextEditingController();
  final _descriptionController = TextEditingController();

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final rating = double.tryParse(_ratingController.text);
      if (rating == null || rating < 0 || rating > 10) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Erro'),
              content: Text('Por favor, insira uma nota válida (0-10)'),
              actions: <Widget>[
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
        return; // Retorna para não adicionar a revisão
      }

      final review = Review(
        user: widget.user,
        rating: rating,
        description: _descriptionController.text,
        game: widget.game,
        timestamp: DateTime.now()
      );

      widget.gameController.addReview(widget.game, review);
      widget.onReviewAdded(); // Call the callback here
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Review'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _ratingController,
                decoration: InputDecoration(labelText: 'Nota (0-10)'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a nota';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Por favor, insira uma nota válida';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Descrição'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a descrição';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Adicionar Review'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
