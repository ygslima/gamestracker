// add_review_screen.dart

import 'package:flutter/material.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';
import '../model/review.dart';
import '../model/user.dart';

class AddReviewScreen extends StatefulWidget {
  final Game game;
  final GameController gameController;
  final User user;
  final VoidCallback onReviewAdded;
  final Review? review;

  AddReviewScreen({required this.game, required this.gameController, required this.user, required this.onReviewAdded, this.review});

  @override
  _AddReviewScreenState createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _ratingController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _ratingController = TextEditingController(text: widget.review?.rating.toString() ?? '');
    _descriptionController = TextEditingController(text: widget.review?.description ?? '');
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final rating = double.tryParse(_ratingController.text);
      if (rating == null || rating < 0 || rating > 10) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Erro'),
              content: Text('Por favor, insira uma nota válida (0-10)'),
              actions: <Widget>[
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
        return; // Retorna para não adicionar a revisão
      }

      if (widget.review != null) {
        widget.review!.rating = rating;
        widget.review!.description = _descriptionController.text;
        widget.review!.timestamp = DateTime.now();
      } else {
        final review = Review(
          user: widget.user,
          rating: rating,
          description: _descriptionController.text,
          game: widget.game,
          timestamp: DateTime.now(),
        );
        widget.gameController.addReview(widget.game, review);
      }

      widget.onReviewAdded(); // Call the callback here
      Navigator.of(context).pop();
    }
  }

  void _deleteReview() {
    if (widget.review != null) {
      widget.gameController.removeReview(widget.game, widget.review!);
      widget.onReviewAdded();
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.review != null ? 'Editar Review' : 'Adicionar Review'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _ratingController,
                decoration: InputDecoration(labelText: 'Nota (0-10)'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a nota';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Por favor, insira uma nota válida';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Descrição'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a descrição';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text(widget.review != null ? 'Salvar Alterações' : 'Adicionar Review'),
              ),
              if (widget.review != null) ...[
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _deleteReview,
                  child: Text('Deletar Review'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
