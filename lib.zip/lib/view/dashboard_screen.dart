import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import '../controller/game_controller.dart';
import 'game_details_screen.dart';
import 'recent_reviews_screen.dart';
import 'login_screen.dart';
import 'add_game_screen.dart';

class DashboardScreen extends StatefulWidget {
  final AuthController authController;


  DashboardScreen({required this.authController});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GameController _gameController = GameController();
  String _searchTerm = '';

  void _addNewGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddGameScreen(
          gameController: _gameController,
          authController: widget.authController,
        ),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              widget.authController.logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.reviews),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RecentReviewsScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Pesquisar jogos'),
                    onChanged: (value) {
                      setState(() {
                        _searchTerm = value;
                      });
                    },
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    // Implementar a busca
                  },
                ),
              ],
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _gameController.games.length,
                itemBuilder: (context, index) {
                  final game = _gameController.games[index];
                  if (_searchTerm.isEmpty || game.name.contains(_searchTerm)) {
                    return ListTile(
                      title: Text(game.name),
                      subtitle: Text(
                        'Média das notas: ${game.reviews.isNotEmpty ? game.reviews.map((e) => e.rating).reduce((a, b) => a + b) / game.reviews.length : 'Sem reviews'}',
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => GameDetailsScreen(
                              game: game,
                              authController: widget.authController,
                            ),
                          ),
                        );
                      },
                    );
                  }
                  return Container();
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: widget.authController.currentUser!.isGuest
          ? null
          : FloatingActionButton(
              onPressed: () => _addNewGame(context),
              child: Icon(Icons.add),
              tooltip: 'Adicionar novo jogo',
            ),
    );
  }
}

