import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import '../controller/game_controller.dart';
import 'game_details_screen.dart';
import 'recent_reviews_screen.dart';
import 'login_screen.dart';
import 'add_game_screen.dart';
import '../model/game.dart';

class DashboardScreen extends StatefulWidget {
  final AuthController authController;

  DashboardScreen({required this.authController});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GameController _gameController = GameController();
  String _searchTerm = '';
  String _sortCriteria = 'date'; // Critério de ordenação inicial

  void _addNewGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddGameScreen(
          gameController: _gameController,
          authController: widget.authController,
        ),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  void _navigateToGameDetails(Game game) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => GameDetailsScreen(
          game: game,
          gameController: _gameController,
          authController: widget.authController,
        ),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  void _sortGames() {
    setState(() {
      if (_sortCriteria == 'date') {
        _gameController.games.sort((a, b) => b.releaseDate.compareTo(a.releaseDate));
      } else if (_sortCriteria == 'rating') {
        _gameController.games.sort((a, b) {
          double aRating = a.reviews.isNotEmpty ? a.reviews.map((e) => e.rating).reduce((a, b) => a + b) / a.reviews.length : 0;
          double bRating = b.reviews.isNotEmpty ? b.reviews.map((e) => e.rating).reduce((a, b) => a + b) / b.reviews.length : 0;
          return bRating.compareTo(aRating);
        });
      } else if (_sortCriteria == 'genre') {
        _gameController.games.sort((a, b) => a.genre.compareTo(b.genre));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _sortGames();

    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              widget.authController.logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.reviews),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RecentReviewsScreen()),
              );
            },
          ),
          DropdownButton<String>(
            value: _sortCriteria,
            items: [
              DropdownMenuItem(value: 'date', child: Text('Ordenar por data')),
              DropdownMenuItem(value: 'rating', child: Text('Ordenar por média de reviews')),
              DropdownMenuItem(value: 'genre', child: Text('Ordenar por gênero')),
            ],
            onChanged: (value) {
              setState(() {
                _sortCriteria = value!;
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Pesquisar jogos'),
                    onChanged: (value) {
                      setState(() {
                        _searchTerm = value;
                      });
                    },
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    // Implementar a busca, se necessário
                  },
                ),
              ],
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _gameController.games.length,
                itemBuilder: (context, index) {
                  final game = _gameController.games[index];
                  bool showGenreHeader = false;

                  if (_sortCriteria == 'genre') {
                    if (index == 0 || game.genre != _gameController.games[index - 1].genre) {
                      showGenreHeader = true;
                    }
                  }

                  if (_searchTerm.isEmpty || game.name.contains(_searchTerm)) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (showGenreHeader)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Text(
                              game.genre,
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ListTile(
                          title: Text(game.name),
                          subtitle: Text(
                            'Média das notas: ${game.reviews.isNotEmpty ? (game.reviews.map((e) => e.rating).reduce((a, b) => a + b) / game.reviews.length).toStringAsFixed(1) : 'Sem reviews'}',
                          ),
                          onTap: () => _navigateToGameDetails(game),
                        ),
                      ],
                    );
                  }
                  return Container();
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addNewGame(context),
        child: Icon(Icons.add),
      ),
    );
  }
}
