import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';
import 'add_review_screen.dart';

class GameDetailsScreen extends StatefulWidget {
  final Game game;
  final GameController gameController;
  final AuthController authController;

  GameDetailsScreen({required this.game, required this.gameController, required this.authController});

  @override
  _GameDetailsScreenState createState() => _GameDetailsScreenState();
}

class _GameDetailsScreenState extends State<GameDetailsScreen> {
  double? _averageRating;

  @override
  void initState() {
    super.initState();
    _calculateAverageRating();
  }

  void _calculateAverageRating() {
    if (widget.game.reviews.isNotEmpty) {
      final totalRating = widget.game.reviews.map((review) => review.rating).reduce((a, b) => a + b);
      setState(() {
        _averageRating = totalRating / widget.game.reviews.length;
      });
    } else {
      setState(() {
        _averageRating = null;
      });
    }
  }

  void _addReview(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddReviewScreen(
          user: widget.authController.currentUser!,
          game: widget.game,
          gameController: widget.gameController,
          onReviewAdded: _updateReviews,
        ),
      ),
    ).then((_) {
      _calculateAverageRating();
      setState(() {});
    });
  }

  void _updateReviews() {
    _calculateAverageRating();
    setState(() {
      // Trigger a rebuild to update the UI
    });
  }

  void _deleteGame(BuildContext context) {
    widget.gameController.deleteGame(widget.game);
    Navigator.of(context).pop(); // Volta para a tela anterior após deletar
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.game.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Nome: ${widget.game.name}', style: TextStyle(fontSize: 20)),
            Text('Gênero: ${widget.game.genre}', style: TextStyle(fontSize: 18)),
            Text('Data de lançamento: ${widget.game.releaseDate.toLocal().toString().split(' ')[0]}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            _averageRating != null
                ? Text('Média das notas: ${_averageRating!.toStringAsFixed(1)}', style: TextStyle(fontSize: 18))
                : Text('Média das notas: Sem reviews', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: widget.authController.currentUser!.isGuest ? null : () => _addReview(context),
              child: Text('Adicionar Review'),
            ),
            SizedBox(height: 20),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                margin: EdgeInsets.only(top: 10.0), // Margem para ajustar o posicionamento vertical
                child: ElevatedButton(
                  onPressed: () => _deleteGame(context),
                  child: Text('Deletar Jogo'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red, // Cor de fundo vermelha
                    foregroundColor: Colors.black, // Texto preto
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Text('Reviews:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: widget.game.reviews.length,
                itemBuilder: (context, index) {
                  final review = widget.game.reviews[index];
                  return ListTile(
                    title: Text('Nota: ${review.rating}'),
                    subtitle: Text(review.description),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
