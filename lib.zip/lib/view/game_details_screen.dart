import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';
import 'add_review_screen.dart';

class GameDetailsScreen extends StatelessWidget {
  final Game game;
  final AuthController authController;

  GameDetailsScreen({required this.game, required this.authController});

  void _addReview(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddReviewScreen(
          game: game,
          gameController: GameController(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(game.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Nome: ${game.name}', style: TextStyle(fontSize: 20)),
            Text('Gênero: ${game.genre}', style: TextStyle(fontSize: 18)),
            Text('Data de lançamento: ${game.releaseDate}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: authController.currentUser!.isGuest ? null : () => _addReview(context),
              child: Text('Adicionar Review'),
            ),
            SizedBox(height: 20),
            Text('Reviews:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: game.reviews.length,
                itemBuilder: (context, index) {
                  final review = game.reviews[index];
                  return ListTile(
                    title: Text('Nota: ${review.rating}'),
                    subtitle: Text(review.description),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
