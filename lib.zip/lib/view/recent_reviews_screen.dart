import 'package:flutter/material.dart';
import '../model/review.dart';
import '../controller/game_controller.dart';

class RecentReviewsScreen extends StatelessWidget {
  final GameController _gameController = GameController();

  List<Review> _getRecentReviews() {
    final now = DateTime.now();
    final sevenDaysAgo = now.subtract(Duration(days: 7));

    List<Review> recentReviews = [];
    for (var game in _gameController.games) {
      for (var review in game.reviews) {
        if (review.timestamp.isAfter(sevenDaysAgo)) {
          recentReviews.add(review);
        }
      }
    }
    return recentReviews;
  }

  @override
  Widget build(BuildContext context) {
    final recentReviews = _getRecentReviews();

    return Scaffold(
      appBar: AppBar(
        title: Text('Reviews Recentes'),
      ),
      body: ListView.builder(
        itemCount: recentReviews.length,
        itemBuilder: (context, index) {
          final review = recentReviews[index];
          return ListTile(
            title: Text('Jogo: ${review.game.name}'),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Nota: ${review.rating}'),
                Text('Descrição: ${review.description}'),
                Text('Usuário: ${review.user.username}'),
              ],
            ),
          );
        },
      ),
    );
  }
}
