import 'package:flutter/material.dart';
import '../controller/game_controller.dart';
import '../model/game.dart';

class EditGameScreen extends StatefulWidget {
  final Game game;
  final GameController gameController;
  final Function(Game) onGameEdited;

  EditGameScreen({required this.game, required this.gameController, required this.onGameEdited});

  @override
  _EditGameScreenState createState() => _EditGameScreenState();
}

class _EditGameScreenState extends State<EditGameScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _releaseDateController;
  late TextEditingController _genreController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.game.name);
    _releaseDateController = TextEditingController(text: widget.game.releaseDate.toLocal().toString().split(' ')[0]);
    _genreController = TextEditingController(text: widget.game.genre);
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final updatedGame = Game(
        id: widget.game.id,
        name: _nameController.text,
        releaseDate: DateTime.parse(_releaseDateController.text),
        genre: _genreController.text,
        creatorId: widget.game.creatorId,
        reviews: widget.game.reviews,
      );

      widget.gameController.editGame(updatedGame, updatedGame.name, updatedGame.releaseDate, updatedGame.genre);
      widget.onGameEdited(updatedGame);
      Navigator.of(context).pop();
    }
  }

  void _deleteGame(BuildContext context) {
    widget.gameController.deleteGame(widget.game);
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Jogo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Nome do jogo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o nome do jogo';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _releaseDateController,
                decoration: InputDecoration(labelText: 'Data de lançamento (YYYY-MM-DD)'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira a data de lançamento';
                  }
                  if (DateTime.tryParse(value) == null) {
                    return 'Por favor, insira uma data válida';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _genreController,
                decoration: InputDecoration(labelText: 'Gênero'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o gênero';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Salvar Alterações'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _deleteGame(context),
                child: Text('Deletar Jogo'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red, // Cor de fundo vermelha
                  foregroundColor: Colors.white, // Texto branco
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
