import 'package:flutter/material.dart';
import '../controller/auth_controller.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthController _authController = AuthController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _errorMessage = '';

  void _handleLogin() {
    if (_authController.login(_usernameController.text, _passwordController.text)) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => DashboardScreen(authController: _authController)),
      );
    } else {
      setState(() {
        _errorMessage = 'Login falhou. Verifique suas credenciais.';
      });
    }
  }

  void _handleRegister() {
    if (_authController.register(_usernameController.text, _passwordController.text)) {
      setState(() {
        _errorMessage = 'Usuário registrado com sucesso. Faça login.';
      });
    } else {
      setState(() {
        _errorMessage = 'Usuário já existe.';
      });
    }
  }

  void _handleGuestLogin() {
    _authController.guestLogin();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => DashboardScreen(authController: _authController)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Games Tracker')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            Text(_errorMessage, style: TextStyle(color: Colors.red)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _handleLogin,
              child: Text('Login'),
            ),
            ElevatedButton(
              onPressed: _handleRegister,
              child: Text('Cadastrar'),
            ),
            ElevatedButton(
              onPressed: _handleGuestLogin,
              child: Text('Entrar como Visitante'),
            ),
          ],
        ),
      ),
    );
  }
}
