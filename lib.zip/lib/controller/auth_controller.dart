import '../model/user.dart';

class AuthController {
  List<User> _users = [];
  User? _currentUser;

  User? get currentUser => _currentUser;

  bool login(String username, String password) {
    for (var user in _users) {
      if (user.username == username && user.password == password) {
        _currentUser = user;
        return true;
      }
    }
    return false;
  }

  bool register(String username, String password) {
    if (_users.any((user) => user.username == username)) {
      return false;
    }
    _users.add(User(username: username, password: password));
    return true;
  }

  void guestLogin() {
    _currentUser = User(username: 'Guest', password: '', isGuest: true);
  }

  void logout() {
    _currentUser = null;
  }
}
