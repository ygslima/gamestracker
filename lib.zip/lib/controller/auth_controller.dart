import '../model/user.dart';

class AuthController {
  List<User> _users = [];
  User? _currentUser;

  User? get currentUser => _currentUser;

  bool login(String username, String password) {
    for (var user in _users) {
      if (user.username == username && user.password == password) {
        _currentUser = user;
        return true;
      }
    }
    return false;
  }

  bool register(String username, String password) {
  if (_users.any((user) => user.username == username)) {
    return false;
  }
  final newUser = User(
    id: DateTime.now().toString(), // ou outro método para gerar um ID único
    username: username,
    password: password,
  );
  _users.add(newUser);
  return true;
}

  void guestLogin() {
  _currentUser = User(
    id: DateTime.now().toString(), // ou outro método para gerar um ID único
    username: 'Guest',
    password: '',
    isGuest: true,
  );
}

  void logout() {
    _currentUser = null;
  }
}
