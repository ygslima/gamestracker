import '../model/game.dart';
import '../model/review.dart';

class GameController {
  List<Game> _games = [];

  List<Game> get games => _games;

  void addGame(Game game) {
    _games.add(game);
  }

  void editGame(Game game, String newName, DateTime newReleaseDate, String newGenre) {
    game.name = newName;
    game.releaseDate = newReleaseDate;
    game.genre = newGenre;
  }

  void deleteGame(Game game) {
    _games.remove(game);
  }

  void addReview(Game game, Review review) {
    try {
      var foundGame = _games.firstWhere((g) => g == game);
      foundGame.reviews.add(review);
    } catch (e) {
      print('Jogo não encontrado');
    }
  }

  void editReview(Review review, double newRating, String newDescription) {
    review.rating = newRating;
    review.description = newDescription;
  }

  void deleteReview(Game game, Review review) {
    game.reviews.remove(review);
  }

  double calculateAverageRating(Game game) {
    if (game.reviews.isEmpty) return 0.0;
    return game.reviews.map((e) => e.rating).reduce((a, b) => a + b) / game.reviews.length;
  }
}
