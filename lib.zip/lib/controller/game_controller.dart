import '../model/game.dart';
import '../model/review.dart';

class GameController {
  List<Game> _games = [];

  List<Game> get games => _games;

  void addGame(Game game) {
    _games.add(game);
  }

  void editGame(Game game, String newName, DateTime newReleaseDate, String newGenre) {
    game.name = newName;
    game.releaseDate = newReleaseDate;
    game.genre = newGenre;
  }

  void deleteGame(Game game) {
    _games.remove(game);
  }

  void addReview(Game game, Review review) {
    game.reviews.add(review);
  }

  void editReview(Review review, double newRating, String newDescription) {
    review.rating = newRating;
    review.description = newDescription;
  }

  void deleteReview(Game game, Review review) {
    game.reviews.remove(review);
  }
}
