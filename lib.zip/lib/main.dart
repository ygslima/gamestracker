import 'package:flutter/material.dart';
import 'view/login_screen.dart';
import 'view/dashboard_screen.dart';
import 'view/add_game_screen.dart';
import 'controller/auth_controller.dart';
import 'controller/game_controller.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final AuthController authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Games Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/dashboard': (context) => DashboardScreen(authController: authController),
        '/login': (context) => LoginScreen(),
        '/add_game': (context) => AddGameScreen(
              gameController: GameController(),
              authController: authController,
            ),
      },
    );
  }
}
