import 'package:gamestracker/model/game.dart';

import 'user.dart';

class Review {
  User user;
  double rating;
  String description;
  Game game;

  Review({required this.user, required this.rating, required this.description, required this.game});

  get timestamp => null;
}
