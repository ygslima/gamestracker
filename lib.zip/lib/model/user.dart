class User {
  final String id;
  String username;
  String password;
  bool isGuest;

  User({required this.id, required this.username, required this.password, this.isGuest = false});
}
