class User {
  String username;
  String password;
  bool isGuest;

  User({required this.username, required this.password, this.isGuest = false});
}
