import 'review.dart';

class Game {
  String name;
  DateTime releaseDate;
  String genre;
  List<Review> reviews;

  Game({required this.name, required this.releaseDate, required this.genre, this.reviews = const []});
}
